// let dropdownMenu;                                     
// $('.dropdown[data-placement="body"]').on('show.bs.dropdown', (e) => {
//   dropdownMenu = $(e.target).find('.dropdown-menu');
//   $('body').append(dropdownMenu.detach());          
//   dropdownMenu.css('display', 'block');             
// });                                                   
// $('.dropdown[data-placement="body"]').on('hide.bs.dropdown', (e) => {        
//   $(e.target).append(dropdownMenu.detach());        
//   dropdownMenu.hide();                              
// });