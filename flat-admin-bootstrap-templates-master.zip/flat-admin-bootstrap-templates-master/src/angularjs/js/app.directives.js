import CONFIG from './config'

export function RegisterDirective() {  
  angular.module(CONFIG["APP"])
}