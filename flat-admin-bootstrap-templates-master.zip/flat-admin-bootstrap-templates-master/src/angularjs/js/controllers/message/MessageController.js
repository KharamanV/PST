class MessageController {
  constructor() {
  }
}

export default MessageController