## Integrate with Ruby on Rails

Integrate with Ruby on Rails is vary easy.

#### [Step 1] Download Templates

You can download or clone templates to your local storage

[Download](https://github.com/tui2tone/flat-admin-bootstrap-templates/archive/v3.0.0.zip) or clone from [Github](https://github.com/tui2tone/flat-admin-bootstrap-templates.git) 

#### [Step 2] Copy Dist Files to Your Projects

`dist/html/assets/css` into `vendors/css`
`dist/html/assets/js` into `vendors/js`